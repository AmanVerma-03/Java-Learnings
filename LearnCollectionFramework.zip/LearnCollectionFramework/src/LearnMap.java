import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
public class LearnMap {

    public static void main(String[] args) {
        Map<String, Integer>mpp = new TreeMap<>();
        mpp.put("one",1);
        mpp.put("two",2);
        mpp.put("three",3);
        mpp.putIfAbsent("four",5);

        for(Map.Entry<String,Integer> e: mpp.entrySet())
        {
            System.out.println(e.getKey());
            System.out.println(e.getValue());
        }
      for( String key: mpp.keySet())
      {
          System.out.println(key);
      }
      for(Integer value : mpp.values())
      {
          System.out.println(value);
      }
    }
}
