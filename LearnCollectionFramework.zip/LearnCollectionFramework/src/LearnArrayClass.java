import java.util.Arrays;

public class LearnArrayClass {
    public static void main(String[] args) {
        int [] numbers = {1,2,3,4,5,6,7,80 , 9} ;
        int index = Arrays.binarySearch(numbers,4);
        System.out.println(index);

        Arrays.sort(numbers);
        for( int i : numbers)
        {
            System.out.println(i + " ");
        }

        //Arrays.fill(numbers,12);


    }
}
