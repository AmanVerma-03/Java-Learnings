import java.util.LinkedList;
import java.util.Queue ;

public class LearnLinkedlistQueue {
    public static void main(String[] args) {

        Queue<Integer>queue = new LinkedList<>() ;
        queue.offer(1);
        queue.offer(24);
        queue.offer(3);
        queue.offer(4);
        queue.offer(5) ;
        queue.add(6);
        System.out.println(queue);
        System.out.println(queue.poll());
        System.out.println(queue.peek());
        //peek : return the heads of the queue ; return null if the queue is empty .

        //remove : returns and removes the head of the queue // throws an exception if the queue is emptty

        //poll return and removes the head of the queue , returns null if the queue is empty .

    }
}
