import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List ;
public class LearnCollectionClass
{
    public static void main(String[] args) {

        List<Integer>list = new ArrayList<>();
        list.add(21);
        list.add(32);
        list.add(42);
        list.add(52);
        list.add(62);
        list.add(72);
        list.add(82);

        System.out.println("min_Elemnent" + Collections.min(list));
        System.out.println("max_element" + Collections.max(list));
        System.out.println(Collections.frequency(list,9));
        System.out.println(list);
    }
}
