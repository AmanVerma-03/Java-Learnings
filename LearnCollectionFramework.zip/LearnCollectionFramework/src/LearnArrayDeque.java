import java.util.ArrayDeque;

public class LearnArrayDeque {
    public static void main(String[] args) {
        ArrayDeque<Integer>adq = new ArrayDeque<>();
        adq.offer(10);
        adq.offer(23);
        adq.offerFirst(45);
        adq.offerLast(80);
        System.out.println("poll  " + adq.poll());
        System.out.println(adq);
    }
}
