import java.util.ArrayList;
import java.util.Iterator;
import java.util.List ;

public class LearnArrayList {

    public static void main(String[] args) {
        ArrayList<String>studentName = new ArrayList<>() ;
        studentName.add("Rakesh");

        List<Integer>list = new ArrayList<>();
        list.add(1);
        list.add(0,45);
        list.add(2,30); // this will add the element at the index at 2
        System.out.println(list.get(0));
        list.remove(0);// this will remove the element present at that index

        list.remove(Integer.valueOf(30)); // this will remove the that particular element .

     list.clear(); // this will remove all the elements from the list .

        System.out.println(list);

        for(int i = 0 ; i < list.size() ; i++)
        {
            System.out.println(list.get(i));
        }


        for(Integer element:list)
            System.out.println(element);

        Iterator<Integer>it = list.iterator() ;
        while(it.hasNext()){
            System.out.println("iterator" + it.next());
        }
    }
}
